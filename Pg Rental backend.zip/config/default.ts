export default {
  port: 1337,
  NODE_ENV: "production",
  dbUri:
    "mongodb+srv://aritra1521:f49rhP00NvDzu2DI@pg-rental.r4zyplj.mongodb.net/?retryWrites=true&w=majority",
  jwt_secret: "MyVerySecret@",
  jwt_expires_in: "1d",
  number_of_salt: 10,
  RAZORPAY_KEY_ID: "rzp_test_ftb5flv3icVffB",
  RAZOR_PAY_KEY_SECRET: "9CIn2hbt4BD0c8OiR1LCNnKS",
};

