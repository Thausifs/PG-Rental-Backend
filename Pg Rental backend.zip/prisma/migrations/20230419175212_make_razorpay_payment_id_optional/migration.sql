-- AlterTable
ALTER TABLE "RentPaymentSubcriptin" ALTER COLUMN "razorpayPaymentId" DROP NOT NULL;
