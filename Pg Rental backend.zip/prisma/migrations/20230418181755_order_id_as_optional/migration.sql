-- AlterTable
ALTER TABLE "AvailAbility" ALTER COLUMN "razorpayPlanId" DROP NOT NULL;
