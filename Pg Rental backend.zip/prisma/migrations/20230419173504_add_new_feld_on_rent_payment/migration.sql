-- AlterTable
ALTER TABLE "RentPaymentSubcriptin" ADD COLUMN     "cancelComment" TEXT;
